A Pen created at CodePen.io. You can find this one at https://codepen.io/slyka85/pen/LbXYKQ.

 